const Database = require("better-sqlite3");
const db = new Database("data/vcc.db", { readonly: true });
const cards = db.prepare("SELECT card_id, card_number, status, available_amount, created_at FROM cards ORDER BY created_at DESC").all();
console.log("=== 所有卡（按创建时间倒序）===");
cards.forEach(function(c) { console.log(JSON.stringify(c)); });
