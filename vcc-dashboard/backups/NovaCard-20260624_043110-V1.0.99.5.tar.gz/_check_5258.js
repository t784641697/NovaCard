const Database = require('better-sqlite3');
const db = new Database('data/vcc.db');

console.log('=== 5258 卡 (2069455464522190849) 详细状态 ===');
const c5258 = db.prepare("SELECT * FROM cards WHERE card_id = '2069455464522190849'").get();
console.log(JSON.stringify(c5258, null, 2));

console.log('\n=== 5556 卡 (XR2067511181878833152) 详细状态 ===');
const c5556 = db.prepare("SELECT * FROM cards WHERE card_id = 'XR2067511181878833152'").get();
console.log(JSON.stringify(c5556, null, 2));

console.log('\n=== 看 cards 表 schema (找 product_code / bin 字段) ===');
const cols = db.prepare("PRAGMA table_info(cards)").all();
console.log(cols.map(c => c.name).join(', '));

console.log('\n=== 两张卡所有 product_code / bin 字段 ===');
console.log('5258:', JSON.stringify(db.prepare("SELECT card_id, card_number, label, product_code, bin, card_bin, product_name FROM cards WHERE card_id = '2069455464522190849'").get(), null, 2));
console.log('5556:', JSON.stringify(db.prepare("SELECT card_id, card_number, label, product_code, bin, card_bin, product_name FROM cards WHERE card_id = 'XR2067511181878833152'").get(), null, 2));

db.close();
