require("dotenv").config();
const axios = require("axios");
const https = require("https");

(async () => {
  // 试 Web API getCardDetails
  const url = "https://ms.vmcardio.com/web/getCardDetails";
  const params = {
    bin: "S5258LL",
    card_id: "2069455464522190849",
    uid: "20112258",  // 从 URL 抓的
    card_type: "save"
  };
  console.log("=== 测试 ms.vmcardio.com/web/getCardDetails (无认证) ===");
  try {
    const resp = await axios.get(url, {
      params,
      httpsAgent: new https.Agent({ family: 4 }),
      timeout: 15000
    });
    console.log("code:", resp.data.code, "msg:", resp.data.msg);
    console.log("完整 data:", JSON.stringify(resp.data, null, 2).slice(0, 2000));
  } catch (e) {
    console.log("ERR:", e.message);
    if (e.response) console.log("响应 status:", e.response.status, "data:", JSON.stringify(e.response.data).slice(0, 500));
  }

  console.log("\n=== 测试 ms.vmcardio.com/web/getCardDetails (带 Token) ===");
  try {
    const t = await axios.get("https://vmapi.vmcardio.com/getAccessToken", {
      params: { app_id: process.env.VMCARDIO_APP_ID, app_secret: process.env.VMCARDIO_APP_SECRET },
      httpsAgent: new https.Agent({ family: 4 }), timeout: 10000
    });
    const token = t.data.data.token;
    const resp = await axios.get(url, {
      params,
      headers: { Authorization: token, "Token": token },
      httpsAgent: new https.Agent({ family: 4 }),
      timeout: 15000
    });
    console.log("code:", resp.data.code, "msg:", resp.data.msg);
    console.log("完整 data:", JSON.stringify(resp.data, null, 2).slice(0, 2000));
  } catch (e) {
    console.log("ERR:", e.message);
    if (e.response) console.log("响应 status:", e.response.status, "data:", JSON.stringify(e.response.data).slice(0, 500));
  }
})().catch(e => console.error("Top ERR:", e.message));
