require('dotenv').config();
const sdk = require('./src/services/vmcardioSDK');
console.log('SDK keys:', Object.keys(sdk));
