const Database = require("better-sqlite3");
const db = new Database("data/vcc.db", { readonly: true });
const c = db.prepare("SELECT card_id, card_number, address_line_one, address_line_two, address_city, address_state, address_country, address_post_code, last_verified, verified_status FROM cards WHERE card_id = '2069455464522190849'").get();
console.log("=== 新卡 DB 里的地址 ===");
console.log(JSON.stringify(c, null, 2));
