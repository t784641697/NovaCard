const Database = require("better-sqlite3");
const db = new Database("data/vcc.db", { readonly: true });

console.log("=== 所有表 ===");
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all();
tables.forEach(function(t) { console.log("  " + t.name); });

console.log("\n=== 用户余额 ===");
const users = db.prepare("SELECT id, email, balance FROM users ORDER BY id").all();
users.forEach(function(u) { console.log(JSON.stringify(u)); });

console.log("\n=== 最近开卡申请 ===");
const apps = db.prepare("SELECT id, user_id, product_code, quantity, topup_amount, status, created_at FROM card_applications ORDER BY id DESC LIMIT 5").all();
apps.forEach(function(a) { console.log(JSON.stringify(a)); });

console.log("\n=== 已有卡 ===");
const cards = db.prepare("SELECT card_id, product_code, available_amount, status, created_at FROM cards ORDER BY created_at DESC LIMIT 5").all();
cards.forEach(function(c) { console.log(JSON.stringify(c)); });
