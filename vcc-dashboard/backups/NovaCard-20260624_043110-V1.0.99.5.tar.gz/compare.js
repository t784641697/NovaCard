require("dotenv").config();
const axios = require("axios");
const https = require("https");
const rsa = require("./src/utils/rsaCrypto");
(async () => {
  const t = await axios.get("https://vmapi.vmcardio.com/getAccessToken", {
    params: { app_id: process.env.VMCARDIO_APP_ID, app_secret: process.env.VMCARDIO_APP_SECRET },
    httpsAgent: new https.Agent({ family: 4 }), timeout: 10000
  });
  const token = t.data.data.token;
  const cardId = "2069455464522190849";
  const content = rsa.encrypt({ card_id: cardId });
  const resp = await axios.post("https://vmapi.vmcardio.com/cardDetail", { content }, {
    headers: { Authorization: token, "Content-Type": "application/json" },
    httpsAgent: new https.Agent({ family: 4 }), timeout: 45000
  });
  const result = rsa.decrypt(resp.data.data);
  console.log("=== card_id 传入:", cardId);
  console.log("=== result.card_id 返回:", result.card_id);
  console.log("=== result.card_number 返回:", result.card_number);
  console.log("=== result.card_address 返回:", JSON.stringify(result.card_address));
  console.log("");
  console.log("=== 完整 result ===");
  console.log(JSON.stringify(result, null, 2));
})().catch(e => console.error("ERR:", e.message));
