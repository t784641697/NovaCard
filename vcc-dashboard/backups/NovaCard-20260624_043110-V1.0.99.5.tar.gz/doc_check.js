require("dotenv").config();
const axios = require("axios");
const https = require("https");
const rsa = require("./src/utils/rsaCrypto");
(async () => {
  const t = await axios.get("https://vmapi.vmcardio.com/getAccessToken", {
    params: { app_id: process.env.VMCARDIO_APP_ID, app_secret: process.env.VMCARDIO_APP_SECRET },
    httpsAgent: new https.Agent({ family: 4 }), timeout: 10000
  });
  const token = t.data.data.token;

  // 试可能的 endpoint
  const endpoints = ["/getCardAddress", "/getBillingAddress", "/getCardBillingAddress", "/cardBillingAddress", "/getCardInfo", "/getCard"];
  for (const ep of endpoints) {
    try {
      const content = rsa.encrypt({ card_id: "2069455464522190849" });
      const resp = await axios.post("https://vmapi.vmcardio.com" + ep, { content }, {
        headers: { Authorization: token, "Content-Type": "application/json" },
        httpsAgent: new https.Agent({ family: 4 }), timeout: 10000
      });
      console.log(ep, "→ code:", resp.data.code, "msg:", resp.data.msg);
    } catch (e) {
      console.log(ep, "→ ERR:", e.response ? e.response.status : e.message);
    }
  }
})().catch(e => console.error("Top ERR:", e.message));
