const Database = require('better-sqlite3');
const db = new Database('data/vcc.db');

console.log('=== 所有表 ===');
console.log(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(t => t.name).join('\n'));

console.log('\n=== user_id=3 账户余额 ===');
const user = db.prepare("SELECT id, email, balance FROM users WHERE id = 3").get();
console.log(JSON.stringify(user, null, 2));

console.log('\n=== 5258 卡当前状态 ===');
const c = db.prepare("SELECT card_id, status, available_amount, updated_at FROM cards WHERE card_id = '2069455464522190849'").get();
console.log(JSON.stringify(c, null, 2));

console.log('\n=== 5556 卡当前状态 ===');
const c2 = db.prepare("SELECT card_id, status, available_amount, updated_at FROM cards WHERE card_id = 'XR2067511181878833152'").get();
console.log(JSON.stringify(c2, null, 2));

db.close();
