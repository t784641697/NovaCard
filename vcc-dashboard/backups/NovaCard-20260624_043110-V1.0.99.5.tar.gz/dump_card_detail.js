require("dotenv").config();
const axios = require("axios");
const https = require("https");
const fs = require("fs");
const rsa = require("./src/utils/rsaCrypto");

(async () => {
  const cardId = "2069455464522190849";
  console.log("1. cardId:", cardId, "type:", typeof cardId);

  // 拿 token
  const t = await axios.get("https://vmapi.vmcardio.com/getAccessToken", {
    params: { app_id: process.env.VMCARDIO_APP_ID, app_secret: process.env.VMCARDIO_APP_SECRET },
    httpsAgent: new https.Agent({ family: 4 }), timeout: 10000
  });
  const token = t.data.data.token;
  console.log("2. token 长度:", token.length);

  // 测一下 rsa.encrypt 是否能正常调用
  const testPayload = { card_id: cardId };
  console.log("3. testPayload:", JSON.stringify(testPayload));
  let content;
  try {
    content = rsa.encrypt(testPayload);
    console.log("4. RSA 加密成功, content 长度:", content.length);
  } catch (e) {
    console.log("4. RSA 加密失败:", e.message);
    console.log("   错误堆栈:", e.stack.split("\n").slice(0, 5).join("\n"));
    return;
  }

  // 调用 cardDetail
  const resp = await axios.post("https://vmapi.vmcardio.com/cardDetail", { content }, {
    headers: { Authorization: token, "Content-Type": "application/json" },
    httpsAgent: new https.Agent({ family: 4 }), timeout: 45000
  });
  console.log("5. cardDetail body.code:", resp.data.code, "msg:", resp.data.msg);

  const result = rsa.decrypt(resp.data.data);
  console.log("\n=== card_address 字段 ===");
  console.log(JSON.stringify(result.card_address, null, 2));
  console.log("\n=== 是否有真实地址:", !!(result.card_address && (result.card_address.address_line_one || result.card_address.city)));
  console.log("\n=== 所有顶层 keys:", Object.keys(result).join(", "));
  console.log("\n=== 完整 result (头 1500 字符) ===");
  console.log(JSON.stringify(result, null, 2).slice(0, 1500));
})().catch(e => {
  console.error("ERR:", e.message);
  if (e.response) console.error("响应:", JSON.stringify(e.response.data).slice(0, 300));
});
