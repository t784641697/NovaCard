require("dotenv").config();
const axios = require("axios");
const https = require("https");
const rsa = require("./src/utils/rsaCrypto");
(async () => {
  const t = await axios.get("https://vmapi.vmcardio.com/getAccessToken", {
    params: { app_id: process.env.VMCARDIO_APP_ID, app_secret: process.env.VMCARDIO_APP_SECRET },
    httpsAgent: new https.Agent({ family: 4 }), timeout: 10000
  });
  const token = t.data.data.token;
  const content = rsa.encrypt({ page: 1, page_size: 5 });
  const resp = await axios.post("https://vmapi.vmcardio.com/cardList", { content }, {
    headers: { Authorization: token, "Content-Type": "application/json" },
    httpsAgent: new https.Agent({ family: 4 }), timeout: 45000
  });
  const result = rsa.decrypt(resp.data.data);
  console.log("=== cardList 返回 keys:", Object.keys(result).join(","));
  if (result.list && result.list[0]) {
    const c = result.list[0];
    console.log("=== 第一张卡 keys:", Object.keys(c).join(","));
    console.log("\n=== 完整第一张卡 ===");
    console.log(JSON.stringify(c, null, 2));
  } else {
    console.log("=== 完整 result ===");
    console.log(JSON.stringify(result, null, 2));
  }
})().catch(e => console.error("ERR:", e.message));
