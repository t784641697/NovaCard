const Database = require("better-sqlite3");
const db = new Database("data/vcc.db", { readonly: true });
const u = db.prepare("SELECT id, email, name, balance, status FROM users WHERE email LIKE 'taoliang%'").get();
console.log("taoliang 用户:", JSON.stringify(u, null, 2));
const allUsers = db.prepare("SELECT id, email, name, role, balance FROM users ORDER BY id").all();
console.log("\n所有用户:");
allUsers.forEach(function(u) { console.log(JSON.stringify(u)); });
