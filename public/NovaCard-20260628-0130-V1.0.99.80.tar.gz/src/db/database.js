/**
 * SQLite 数据库初始化
 * 表：users, cards
 */
const Database = require('better-sqlite3');
const path     = require('path');
const bcrypt   = require('bcryptjs');

const DB_PATH = path.resolve(__dirname, '../../data/vcc.db');

// 确保 data 目录存在
const fs = require('fs');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);

// 使用 DELETE 模式避免 PM2 重启时 WAL 损坏
db.pragma('journal_mode = DELETE');
db.pragma('foreign_keys = ON');

// 注册 nowiso() SQL 函数 → 输出 ISO 8601 UTC 时间戳
// 统一项目中所有 SQL 侧的时间戳格式：nowiso() 替代 datetime('now')
db.function('nowiso', { deterministic: true }, () => new Date().toISOString());

// ── 建表 ─────────────────────────────────────────────────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    email           TEXT    UNIQUE NOT NULL,
    password        TEXT    NOT NULL,
    name            TEXT    NOT NULL DEFAULT '',
    role            TEXT    NOT NULL DEFAULT 'user',  -- 'user' | 'admin'
    balance         REAL    NOT NULL DEFAULT 0,
    status          TEXT    NOT NULL DEFAULT 'active', -- active / locked / disabled
    login_fail_cnt  INTEGER NOT NULL DEFAULT 0,        -- 连续失败次数
    locked_until    TEXT    NOT NULL DEFAULT '',       -- 锁定到期时间（ISO 字符串）
    last_login_at   TEXT    NOT NULL DEFAULT '',
    last_login_ip   TEXT    NOT NULL DEFAULT '',
    created_at      TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at      TEXT    NOT NULL DEFAULT (nowiso())
  );

  -- 审计日志表
  CREATE TABLE IF NOT EXISTS audit_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER,              -- 可为 NULL（未登录请求）
    action     TEXT    NOT NULL,     -- login_ok / login_fail / register / logout / ...
    ip         TEXT    NOT NULL DEFAULT '',
    ua         TEXT    NOT NULL DEFAULT '',
    detail     TEXT    NOT NULL DEFAULT '',  -- JSON 附加信息
    created_at TEXT    NOT NULL DEFAULT (nowiso())
  );
  CREATE INDEX IF NOT EXISTS idx_audit_user_id   ON audit_logs(user_id);
  CREATE INDEX IF NOT EXISTS idx_audit_action    ON audit_logs(action);
  CREATE INDEX IF NOT EXISTS idx_audit_created   ON audit_logs(created_at);
  CREATE INDEX IF NOT EXISTS idx_audit_ip        ON audit_logs(ip);

  -- 图形验证码存储表
  CREATE TABLE IF NOT EXISTS captcha_store (
    token      TEXT    PRIMARY KEY,
    text       TEXT    NOT NULL,    -- 答案（小写）
    expires_at TEXT    NOT NULL,
    used       INTEGER NOT NULL DEFAULT 0
  );

  -- 短信验证码表
  CREATE TABLE IF NOT EXISTS sms_codes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    phone       TEXT    NOT NULL,
    code        TEXT    NOT NULL,
    purpose     TEXT    NOT NULL DEFAULT 'register',  -- register / login / reset
    expires_at  TEXT    NOT NULL,
    used        INTEGER NOT NULL DEFAULT 0,
    ip          TEXT    NOT NULL DEFAULT '',
    created_at  TEXT    NOT NULL DEFAULT (nowiso())
  );
  CREATE INDEX IF NOT EXISTS idx_sms_phone ON sms_codes(phone);
  CREATE INDEX IF NOT EXISTS idx_sms_expires ON sms_codes(expires_at);

  CREATE TABLE IF NOT EXISTS cards (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    card_id          TEXT    UNIQUE NOT NULL,   -- vmcardio card_id
    card_number      TEXT    NOT NULL DEFAULT '',  -- 卡号（虚拟卡号）
    product_code     TEXT    NOT NULL DEFAULT '',
    label            TEXT    NOT NULL DEFAULT '',
    status           TEXT    NOT NULL DEFAULT 'active',
    available_amount REAL    NOT NULL DEFAULT 0,   -- 卡内余额（vmcardio 同步）
    expiry_month     INTEGER NOT NULL DEFAULT 0,   -- 到期月
    expiry_year      INTEGER NOT NULL DEFAULT 0,   -- 到期年
    cvv              TEXT    NOT NULL DEFAULT '',  -- CVV（加密存储）
    created_at       TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at       TEXT    NOT NULL DEFAULT (nowiso())
  );

  CREATE INDEX IF NOT EXISTS idx_cards_user_id ON cards(user_id);
  CREATE INDEX IF NOT EXISTS idx_cards_card_id  ON cards(card_id);

  CREATE TABLE IF NOT EXISTS settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT (nowiso())
  );

  -- 公告表
  CREATE TABLE IF NOT EXISTS announcements (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT    NOT NULL DEFAULT '',
    content    TEXT    NOT NULL DEFAULT '',
    type       TEXT    NOT NULL DEFAULT '运营公告',
    is_active  INTEGER NOT NULL DEFAULT 1,
    created_at TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at TEXT    NOT NULL DEFAULT (nowiso())
  );

  CREATE TABLE IF NOT EXISTS upstream_fees (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    fee_type       TEXT    UNIQUE NOT NULL,
    name           TEXT    NOT NULL DEFAULT '',
    upstream_rate  REAL    NOT NULL DEFAULT 0,
    upstream_fixed REAL    NOT NULL DEFAULT 0,
    rules          TEXT    NOT NULL DEFAULT '{}',
    notes          TEXT    NOT NULL DEFAULT '',
    updated_at     TEXT    NOT NULL DEFAULT (nowiso())
  );

  -- 企业认证（KYC）申请表
  CREATE TABLE IF NOT EXISTS kyc_applications (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id           INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    company_name      TEXT    NOT NULL DEFAULT '',
    contact_name      TEXT    NOT NULL DEFAULT '',
    contact_phone     TEXT    NOT NULL DEFAULT '',
    business_license  TEXT    NOT NULL DEFAULT '',
    status            TEXT    NOT NULL DEFAULT 'pending',  -- pending / approved / rejected
    reject_reason     TEXT    NOT NULL DEFAULT '',
    submitter_ip      TEXT    NOT NULL DEFAULT '',
    created_at        TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at        TEXT    NOT NULL DEFAULT (nowiso())
  );
  CREATE INDEX IF NOT EXISTS idx_kyc_user_id ON kyc_applications(user_id);
  CREATE INDEX IF NOT EXISTS idx_kyc_status ON kyc_applications(status);

  -- upstream_fees 种子数据（与 fee_configs 类型对应）
  INSERT OR IGNORE INTO upstream_fees (fee_type, name, upstream_rate, upstream_fixed, rules) VALUES
    ('card_creation',     '开卡费',          0,    10.00, '{"charge_timing":"创建时收取"}'),
    ('transaction',       '交易手续费',      0.03,  0.30, '{"free_count":"5","charge_timing":"逐笔"}'),
    ('refund',            '退款手续费',      0.05,  0.50, '{"charge_timing":"退款时"}'),
    ('chargeback',        '拒付手续费',      0.08,  2.00, '{"charge_timing":"拒付发生时"}'),
    ('auth_reversal',     '授权撤销费',      0,     0,    '{"exempt":"免费"}'),
    ('cross_border',      '跨境交易附加费',  0.01,  0.45, '{"threshold":"单笔≥$100","charge_timing":"超额部分"}'),
    ('small_transaction', '小额交易附加费',  0,     0,    '{"threshold":"<$3","charge_timing":"每笔"}'),
    ('card_monthly',      '卡片月管理费',    0,     3.00, '{"charge_timing":"每月","exempt":"首月免费"}');

  CREATE TABLE IF NOT EXISTS topup_requests (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    network      TEXT    NOT NULL DEFAULT '',   -- TRC20 / ERC20 / BEP20 / SOL
    amount_usdt  REAL    NOT NULL DEFAULT 0,    -- 用户填写的 USDT 金额（选填则为0）
    txhash       TEXT    NOT NULL DEFAULT '',   -- 链上哈希（选填）
    remark       TEXT    NOT NULL DEFAULT '',
    status       TEXT    NOT NULL DEFAULT 'pending',  -- pending / approved / rejected
    fee_rate     REAL    NOT NULL DEFAULT 0,    -- 申请时锁定的入账手续费率
    fee_amount   REAL    NOT NULL DEFAULT 0,    -- 申请时锁定的手续费金额（USD）
    net_amount   REAL    NOT NULL DEFAULT 0,    -- 申请时锁定的实到金额（USD）
    created_at   TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at   TEXT    NOT NULL DEFAULT (nowiso())
  );

  CREATE INDEX IF NOT EXISTS idx_topup_user_id ON topup_requests(user_id);
  CREATE INDEX IF NOT EXISTS idx_topup_status  ON topup_requests(status);

  -- 上游交易流水表（同步 vmcardio /cardTransaction）
  CREATE TABLE IF NOT EXISTS card_transactions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    auth_id       TEXT,
    card_id       TEXT    NOT NULL,
    type          TEXT    NOT NULL,             -- Authorization / Settlement / Refund / Reversal
    status        TEXT,                          -- COMPLETE / DECLINED / PENDING
    auth_amount   REAL    DEFAULT 0,
    settle_amount REAL    DEFAULT 0,
    auth_currency TEXT    DEFAULT 'USD',
    settle_currency TEXT   DEFAULT 'USD',
    merchant_name TEXT,
    create_time   TEXT,
    auth_time     TEXT,
    sync_time     TEXT    DEFAULT (nowiso())
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_ct_auth_id ON card_transactions(auth_id);
  CREATE INDEX IF NOT EXISTS idx_ct_card_id ON card_transactions(card_id);
  CREATE INDEX IF NOT EXISTS idx_ct_type ON card_transactions(type);
  CREATE INDEX IF NOT EXISTS idx_ct_create_time ON card_transactions(create_time);

  CREATE TABLE IF NOT EXISTS card_applications (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    -- 申请参数（完整存储，审批通过时直接用来调 vmcardio）
    product_code TEXT    NOT NULL DEFAULT '',
    card_bin     TEXT    NOT NULL DEFAULT '',
    first_name   TEXT    NOT NULL DEFAULT '',
    last_name    TEXT    NOT NULL DEFAULT '',
    label        TEXT    NOT NULL DEFAULT '',
    -- 新开卡参数：充值金额（每张卡最低$20） + 开卡数量
    topup_amount REAL    NOT NULL DEFAULT 0,
    quantity     INTEGER NOT NULL DEFAULT 1,
    email        TEXT    NOT NULL DEFAULT '',
    -- 开卡费（已扣除的开卡费，存为记录便于审计）
    fee_amount   REAL    NOT NULL DEFAULT 0,
    -- 审批状态
    status       TEXT    NOT NULL DEFAULT 'pending',  -- pending / approved / rejected
    reject_reason TEXT   NOT NULL DEFAULT '',
    -- 审批通过后 vmcardio 返回的 card_id
    card_id      TEXT    NOT NULL DEFAULT '',
    -- 时间
    created_at   TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at   TEXT    NOT NULL DEFAULT (nowiso())
  );

  CREATE INDEX IF NOT EXISTS idx_card_app_user_id ON card_applications(user_id);
  CREATE INDEX IF NOT EXISTS idx_card_app_status  ON card_applications(status);

  -- 交易流水表
  CREATE TABLE IF NOT EXISTS transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type            TEXT    NOT NULL DEFAULT '',      -- 消费 / 退款 / 拒付 / 充值 / 手续费 / ...
    amount          REAL    NOT NULL DEFAULT 0,        -- 交易金额（正数表示收入，负数表示支出）
    fee_type        TEXT    NOT NULL DEFAULT '',        -- 费用类型：transaction/cross_border/small_transaction/...
    fee_amount      REAL    NOT NULL DEFAULT 0,        -- 手续费金额
    fee_rate        REAL    NOT NULL DEFAULT 0,        -- 使用的费率
    fee_fixed       REAL    NOT NULL DEFAULT 0,        -- 使用的固定费
    net_amount      REAL    NOT NULL DEFAULT 0,        -- 净变动额
    description     TEXT    NOT NULL DEFAULT '',
    ref_id          TEXT    NOT NULL DEFAULT '',        -- 外部引用ID（如 auth_id）
    created_at      TEXT    NOT NULL DEFAULT (nowiso())
  );
  CREATE INDEX IF NOT EXISTS idx_txn_user_id  ON transactions(user_id);
  CREATE INDEX IF NOT EXISTS idx_txn_type     ON transactions(type);
  CREATE INDEX IF NOT EXISTS idx_txn_fee_type ON transactions(fee_type);
  CREATE INDEX IF NOT EXISTS idx_txn_ref_id   ON transactions(ref_id);
  CREATE INDEX IF NOT EXISTS idx_txn_created  ON transactions(created_at);

  -- 全局费率配置表
  CREATE TABLE IF NOT EXISTS fee_configs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    fee_type    TEXT    UNIQUE NOT NULL,              -- card_creation / transaction / refund / chargeback / cross_border / small_transaction / withdrawal / auth_reversal / management
    description TEXT    NOT NULL,
    fee_rate    REAL    NOT NULL DEFAULT 0,           -- 百分比费率，如 0.05=5%
    fee_fixed   REAL    NOT NULL DEFAULT 0,           -- 固定费用（美元）
    min_amount  REAL    NOT NULL DEFAULT 0,
    max_amount  REAL    NOT NULL DEFAULT 0,           -- 0=无限制
    currency    TEXT    NOT NULL DEFAULT 'USD',
    is_active   INTEGER NOT NULL DEFAULT 1,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at  TEXT    NOT NULL DEFAULT (nowiso())
  );
  CREATE INDEX IF NOT EXISTS idx_fee_configs_type ON fee_configs(fee_type, is_active);

  -- 用户级自定义费率表
  CREATE TABLE IF NOT EXISTS user_fee_configs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    fee_type    TEXT    NOT NULL,
    fee_rate    REAL    DEFAULT NULL,
    fee_fixed   REAL    DEFAULT NULL,
    min_amount  REAL    DEFAULT NULL,
    max_amount  REAL    DEFAULT NULL,
    is_active   INTEGER NOT NULL DEFAULT 1,
    notes       TEXT,
    created_at  TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at  TEXT    NOT NULL DEFAULT (nowiso()),
    UNIQUE(user_id, fee_type)
  );

  -- v1.0.24 管理员卡段业务配置（覆盖 HARDCODED 和 docx metadata）
  CREATE TABLE IF NOT EXISTS card_product_overrides (
    product_code           TEXT PRIMARY KEY,
    available              INTEGER NOT NULL DEFAULT 1,         -- 0=关闭（用户端置灰），1=开启
    applicable_platforms   TEXT    DEFAULT NULL,               -- JSON 数组,例如 '["Facebook","Google"]'
    custom_message         TEXT    DEFAULT NULL,               -- 自定义消息(用户端展示)
    updated_at             INTEGER NOT NULL,
    updated_by             TEXT    DEFAULT NULL                 -- 管理员邮箱
  );

  -- v1.0.70 场景配置表 (管理员在线配置"平台→场景"映射)
  CREATE TABLE IF NOT EXISTS scenario_mappings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    scenario_name   TEXT    NOT NULL UNIQUE,                   -- 场景名称: '社交媒体'
    scenario_icon   TEXT    NOT NULL DEFAULT '',                -- emoji: '🌐'
    sort_order      INTEGER NOT NULL DEFAULT 0,                 -- 排序
    platforms       TEXT    NOT NULL DEFAULT '[]',              -- JSON 数组: ["Facebook","OpenAI"]
    enabled         INTEGER NOT NULL DEFAULT 1,                 -- 0=禁用, 1=启用
    created_at      TEXT    NOT NULL DEFAULT (nowiso()),
    updated_at      TEXT    NOT NULL DEFAULT (nowiso())
  );
  CREATE INDEX IF NOT EXISTS idx_user_fee_configs ON user_fee_configs(user_id, fee_type, is_active);
  CREATE INDEX IF NOT EXISTS idx_scenario_sort    ON scenario_mappings(sort_order);

  -- v1.0.75 卡段"首次出现"滑动窗口追踪
  --   单行表: 记录上一次上游拉取的 product_code 列表 (JSON 数组)
  --   每次 /api/cards/meta/products 拉取上游后, 对比 last_seen 算出 is_new,
  --   然后用当前列表覆盖 last_seen. 首次部署后第一次拉取时做"自动种子化"
  --   (直接用当前列表填充 last_seen, 不返回 NEW), 避免 admin 看到 17 个假 NEW
  CREATE TABLE IF NOT EXISTS card_product_last_seen (
    id          INTEGER PRIMARY KEY CHECK (id = 1),            -- 永远只有 1 行
    codes       TEXT    NOT NULL DEFAULT '[]',                 -- JSON 字符串数组
    updated_at  TEXT    NOT NULL DEFAULT (nowiso())
  );
`);

// ── Schema 迁移：补全旧版本缺少的字段 ───────────────────────────────────
(function migrate() {
  // 迁移计数器：避免每次启动刷一堆"已存在"日志
  let addedCount = 0;
  let skippedCount = 0;
  let errorCount = 0;

  // users 表迁移
  const cols = db.prepare("PRAGMA table_info(users)").all().map(c => c.name);
  const add = (col, def) => {
    if (cols.includes(col)) { skippedCount++; return; }
    try {
      db.exec(`ALTER TABLE users ADD COLUMN ${col} ${def}`);
      console.log(`[DB Migration] users 表已添加列: ${col}`);
      addedCount++;
    } catch (e) {
      console.warn(`[DB Migration] users.${col} ALTER 失败: ${e.message}`);
      errorCount++;
    }
  };
  add('status',         "TEXT    NOT NULL DEFAULT 'active'");
  add('login_fail_cnt', "INTEGER NOT NULL DEFAULT 0");
  add('locked_until',   "TEXT    NOT NULL DEFAULT ''");
  add('last_login_at',  "TEXT    NOT NULL DEFAULT ''");
  add('last_login_ip',  "TEXT    NOT NULL DEFAULT ''");
  // 余额相关统计字段
  add('phone',          "TEXT    DEFAULT NULL");
  add('initial_balance',"REAL    DEFAULT 0");
  add('topup_total',    "REAL    DEFAULT 0");
  add('topup_net_total',"REAL    DEFAULT 0");  // 累计实到金额（扣手续费后）
  add('total_spend',    "REAL    DEFAULT 0");
  add('total_refund',   "REAL    DEFAULT 0");
  add('total_dispute',  "REAL    DEFAULT 0");
  add('total_fees',     "REAL    DEFAULT 0");
  add('last_fee_update',"TEXT");
  add('total_chargeback',"REAL   DEFAULT 0");
  add('kyc_status',      "TEXT   NOT NULL DEFAULT 'none'");

  // cards 表迁移
  const cardCols = db.prepare("PRAGMA table_info(cards)").all().map(c => c.name);
  const addCard = (col, def) => {
    if (cardCols.includes(col)) { skippedCount++; return; }
    try {
      db.exec(`ALTER TABLE cards ADD COLUMN ${col} ${def}`);
      console.log(`[DB Migration] cards 表已添加列: ${col}`);
      addedCount++;
    } catch (e) {
      console.warn(`[DB Migration] cards.${col} ALTER 失败: ${e.message}`);
      errorCount++;
    }
  };
  addCard('card_type',        "TEXT    DEFAULT ''");
  addCard('single_limit',     "REAL    DEFAULT 0");
  addCard('day_limit',        "REAL    DEFAULT 0");
  addCard('month_limit',      "REAL    DEFAULT 0");
  addCard('last_verified',    "TEXT    DEFAULT ''");
  addCard('verified_status',  "TEXT    DEFAULT ''");
  addCard('verification_error',"TEXT   DEFAULT ''");
  addCard('first_name',       "TEXT    DEFAULT ''");
  addCard('last_name',        "TEXT    DEFAULT ''");

  // topup_requests 老表加列（兜底迁移：v1.0.14 之前的老库没 fee/net 字段）
  const topupCols = db.prepare("PRAGMA table_info(topup_requests)").all().map(c => c.name);
  const addTopup = (col, type) => {
    if (topupCols.includes(col)) { skippedCount++; return; }
    try {
      db.exec(`ALTER TABLE topup_requests ADD COLUMN ${col} ${type}`);
      console.log(`[DB Migration] topup_requests 表已添加列: ${col}`);
      addedCount++;
    } catch (e) {
      console.warn(`[DB Migration] topup_requests.${col} ALTER 失败: ${e.message}`);
      errorCount++;
    }
  };
  addTopup('fee_rate',   "REAL    NOT NULL DEFAULT 0");
  addTopup('fee_amount', "REAL    NOT NULL DEFAULT 0");
  addTopup('net_amount', "REAL    NOT NULL DEFAULT 0");

  // card_applications 老表加列（兜底迁移：v1.0.15 之前的老库没 fee_amount 字段，
  // 导致普通用户开卡申请 POST /api/cards 报 500 "no column named fee_amount"）
  const cardAppCols = db.prepare("PRAGMA table_info(card_applications)").all().map(c => c.name);
  const addCardApp = (col, type) => {
    if (cardAppCols.includes(col)) { skippedCount++; return; }
    try {
      db.exec(`ALTER TABLE card_applications ADD COLUMN ${col} ${type}`);
      console.log(`[DB Migration] card_applications 表已添加列: ${col}`);
      addedCount++;
    } catch (e) {
      console.warn(`[DB Migration] card_applications.${col} ALTER 失败: ${e.message}`);
      errorCount++;
    }
  };
  addCardApp('fee_amount', "REAL    NOT NULL DEFAULT 0");

  // fee_configs 种子数据（INSERT OR IGNORE 保证幂等）
  // 迁移：将旧的 dispute 记录删除（已被 chargeback 替代）
  db.prepare(`DELETE FROM fee_configs WHERE fee_type = 'dispute'`).run();

  const seedFees = [
    ['card_creation',     '开卡费',       0,     10.00,  0,  0,  10],
    ['topup',             '入账手续费',    0.02,  0,     0,  0,  15],  // 用户充值 100 → 扣 2% → 实到 98
    ['transaction',       '交易手续费',   0.03,   0.30,  0,  0,  20],
    ['refund',            '退款手续费',   0.05,   0.50,  0,  0,  30],
    ['chargeback',        '拒付手续费',   0.08,   2.00,  0,  0,  40],
    ['cross_border',      '跨境交易费',   0.01,   0.45,  0,  0,  50],
    ['small_transaction', '小额授权费',   0,      0.50,  0,  0,  55],
    ['withdrawal',        '提现手续费',   0.02,   1.00,  0,  0,  60],
    ['auth_reversal',     '撤销手续费',   0.05,   0.50,  0,  0,  65],
    ['management',        '管理费',       0,      0,     0,  0,  70],
  ];
  const insertFee = db.prepare(`
    INSERT OR IGNORE INTO fee_configs (fee_type, description, fee_rate, fee_fixed, min_amount, max_amount, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  let feeAdded = 0;
  let feeExisted = 0;
  for (const [feeType, desc, rate, fixed, minAmt, maxAmt, sort] of seedFees) {
    const r = insertFee.run(feeType, desc, rate, fixed, minAmt, maxAmt, sort);
    if (r.changes > 0) {
      console.log(`[DB Seed] fee_configs: ${feeType} ✓ 新增`);
      feeAdded++;
    } else {
      console.log(`[DB Seed] fee_configs: ${feeType} - 已存在`);
      feeExisted++;
    }
  }
  console.log(`[DB Seed] fee_configs 完成: 新增 ${feeAdded} 项, 已存在 ${feeExisted} 项`);

  // 更新已存在的 cross_border 为正确的值（1% + $0.45）
  db.prepare(`UPDATE fee_configs SET fee_rate = 0.01, fee_fixed = 0.45, updated_at = nowiso() WHERE fee_type = 'cross_border'`).run();

  // 同步重命名：老记录 '充值入账手续费' → '入账手续费'（2026-06 重命名）
  const renTopup = db.prepare(`UPDATE fee_configs SET description = '入账手续费', updated_at = nowiso() WHERE fee_type = 'topup' AND description = '充值入账手续费'`).run();
  if (renTopup.changes > 0) console.log(`[DB Seed] fee_configs: topup description 重命名 (${renTopup.changes} 条)`);

  // ── 迁移完成汇总日志（每次启动都打，方便确认 migrate 跑过）──────────
  console.log(`[migrate] ✓ 完成: 新增 ${addedCount} 列, 已存在 ${skippedCount} 列, 失败 ${errorCount} 列 (users/cards/topup_requests/card_applications 合计)`);
  if (errorCount > 0) {
    console.warn(`[migrate] ⚠️ 有 ${errorCount} 个 ALTER 失败，请检查上方错误日志`);
  }
})();

// ── 种子数据（首次运行插入默认账号）──────────────────────────────────────

// ── 默认账号密码（符合强度规则：8-16位/大写/小写/数字/特殊字符）──
// 管理员：admin@vcc.hub / Admin@2026
// 测试用：user@vcc.hub  / User@20261
const seedAdmin = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@vcc.hub');
if (!seedAdmin) {
  const hash = bcrypt.hashSync('Admin@2026', 12);
  db.prepare(`
    INSERT INTO users (email, password, name, role, balance)
    VALUES (?, ?, ?, 'admin', 0)
  `).run('admin@vcc.hub', hash, 'Admin');
  console.log('[DB] 已插入默认管理员账号 admin@vcc.hub / Admin@2026');
}

const seedUser = db.prepare('SELECT id FROM users WHERE email = ?').get('user@vcc.hub');
if (!seedUser) {
  const hash = bcrypt.hashSync('User@20261', 12);
  db.prepare(`
    INSERT INTO users (email, password, name, role, balance)
    VALUES (?, ?, ?, 'user', 0)
  `).run('user@vcc.hub', hash, 'TestUser');
  console.log('[DB] 已插入默认用户账号 user@vcc.hub / User@20261');
}

// ── 场景映射种子数据 (v1.0.70) ──
// 服务首次启动时插入 3 个默认场景: 社交媒体/电商/AI订阅
// 已存在则跳过 (使用 INSERT OR IGNORE)
const seedScenarios = [
  {
    name: '社交媒体',
    icon: '🌐',
    sort_order: 1,
    platforms: ['Facebook','Instagram','Twitter','X','TikTok','Telegram','YouTube','Reddit','Snapchat','Pinterest','LinkedIn','Discord']
  },
  {
    name: '电商',
    icon: '🛒',
    sort_order: 2,
    platforms: ['Amazon','Shopify','Walmart','eBay','Etsy','Alibaba','AliExpress','Mercado','Lazada','Shopee','Tmall','Taobao']
  },
  {
    name: 'AI订阅',
    icon: '🤖',
    sort_order: 3,
    platforms: ['OpenAI','ChatGPT','Midjourney','Claude','Anthropic','Cursor','GitHub Copilot','Perplexity','Notion AI','Jasper','Runway','Suno','Poe','Hugging Face']
  }
];
const insertScenario = db.prepare(`
  INSERT OR IGNORE INTO scenario_mappings (scenario_name, scenario_icon, sort_order, platforms, enabled)
  VALUES (?, ?, ?, ?, 1)
`);
for (const s of seedScenarios) {
  const result = insertScenario.run(s.name, s.icon, s.sort_order, JSON.stringify(s.platforms));
  if (result.changes > 0) {
    console.log(`[DB] 已插入默认场景: ${s.icon} ${s.name} (${s.platforms.length} 个平台关键词)`);
  }
}

// ── announcements 表兼容升级 ──
(() => {
  try {
    const annCols = db.prepare("PRAGMA table_info(announcements)").all().map(c => c.name);
    if (!annCols.includes('type')) {
      db.exec("ALTER TABLE announcements ADD COLUMN type TEXT DEFAULT '运营公告'");
      console.log('[DB Migration] announcements 表已添加列: type');
    }
  } catch(e) { console.error('[DB Migration] announcements 升级失败:', e.message); }
})();

// ── kyc_applications 表兼容升级（remark 列） ──
(() => {
  try {
    const kycCols = db.prepare("PRAGMA table_info(kyc_applications)").all().map(c => c.name);
    if (!kycCols.includes('remark')) {
      db.exec("ALTER TABLE kyc_applications ADD COLUMN remark TEXT DEFAULT ''");
      console.log('[DB Migration] kyc_applications 表已添加列: remark');
    }
  } catch(e) { console.error('[DB Migration] kyc_applications 升级失败:', e.message); }
})();

// ── kyc_applications 企业认证扩展字段 ──
(() => {
  try {
    const kycCols = db.prepare("PRAGMA table_info(kyc_applications)").all().map(c => c.name);
    const newCols = [
      { name: 'country',            desc: '国家/地区' },
      { name: 'legal_person_name',  desc: '法人姓名' },
      { name: 'legal_person_id',    desc: '法人身份证号' },
      { name: 'reg_cert_file',      desc: '企业注册证书文件' },
      { name: 'id_card_file',       desc: '法人身份证文件' },
      { name: 'email',              desc: '联系邮箱' },
    ];
    newCols.forEach(({ name, desc }) => {
      if (!kycCols.includes(name)) {
        db.exec(`ALTER TABLE kyc_applications ADD COLUMN ${name} TEXT DEFAULT ''`);
        console.log(`[DB Migration] kyc_applications 表已添加列: ${name} (${desc})`);
      }
    });
  } catch(e) { console.error('[DB Migration] kyc_applications 扩展字段升级失败:', e.message); }
})();

// ── 重建所有索引，防止跨版本 schema 不一致导致 SQLITE_CORRUPT ──
try { db.exec('REINDEX'); } catch(e) { console.error('[DB] REINDEX failed:', e.message); }

module.exports = db;
